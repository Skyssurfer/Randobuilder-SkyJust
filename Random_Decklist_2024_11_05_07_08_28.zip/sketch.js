let deck = 0;

function setup() {
  createCanvas(400, 400);
  
  loadJSON("http://api.open-notify.org/astros.json", gotData)
}

// load json file
// make button of colors to choose, maybe type??
// find by color or mana cost??
// random builder of 60


function gotData(data) {
spaceData = data;
}

function deckBuild(){
  if (deck == 1){
  // pull a random 60 of cards
}
}


function draw() {
  background(220);
  
}



